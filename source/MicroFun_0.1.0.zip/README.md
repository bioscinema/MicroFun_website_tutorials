# MicroFun

**MicroFun** is an R package for differential analysis and visualization of taxon-stratified microbial functional profiles predicted by PICRUSt2. It integrates functional contribution tables with `phyloseq` data to examine relationships between microbial taxa and predicted functions.

**[Documentation and tutorials](https://bioscinema.github.io/MicroFun_website_tutorials/)** · [GitHub](https://github.com/bioscinema/MicroFun_0.1.0) · [Issues](https://github.com/bioscinema/MicroFun_0.1.0/issues)

## Features

- **Bidirectional analysis:** identify differential functions within taxa (*tax2fun*) or differential taxonomic contributions to functions (*fun2tax*).
- **Functional profiling:** work with KO, EC, MetaCyc and supported KEGG pathway contributions, with functional annotations.
- **Taxonomic aggregation:** analyze stratified contributions at selected taxonomic ranks.
- **Visualization:** Sankey diagrams with taxonomic or phylogenetic trees, chord diagrams, boxplots, association dendrograms and effect-size plots.
- **Additional analyses:** differential abundance testing, heatmaps, PCA and error-bar plots.

## Installation

```r
install.packages("remotes")
remotes::install_github("bioscinema/MicroFun_0.1.0", dependencies = TRUE)

library(MicroFun)
```

## Quick start

MicroFun uses a PICRUSt2 stratified contribution table and a `phyloseq` object containing ASV taxonomy and sample metadata. The contribution table contains the columns `sample`, `taxon`, `function` and `taxon_function_abun`.

```r
library(MicroFun)

ps <- readRDS("phyloseq.rds")
contributions <- "KO_contrib.tsv.gz"

# Taxon-to-function analysis
taxa_result <- pathway_sdaa(
  stratified_path = contributions,
  physeq = ps,
  group = "Group",
  reference = "Control",
  taxon_level = "Genus",
  pathway = "KO",
  direction = "taxa",
  daa_method = "Maaslin2"
)

# Function-to-taxon analysis
function_result <- pathway_sdaa(
  stratified_path = contributions,
  physeq = ps,
  group = "Group",
  reference = "Control",
  taxon_level = "Genus",
  pathway = "KO",
  direction = "function",
  daa_method = "Maaslin2"
)
```

### Visualization

```r
p1 <- tax2fun_sankey(taxa_result, tree_mode = "taxonomy", physeq = ps)
save_sankey(p1, "tax2fun.html")

p2 <- fun2tax_sankey(
  function_result,
  group_functions = FALSE,
  tree_mode = "taxonomy",
  physeq = ps
)
save_sankey(p2, "fun2tax.html")
```

MicroFun also provides `tax2fun_chord()`, `fun2tax_chord()`, `tax2fun_box()`, `fun2tax_box()`, `tax2fun_dendro()`, `fun2tax_dendro()`, `tax2fun_logfc()` and `fun2tax_logfc()` for complementary visualizations.

## Documentation

Full workflows, input preparation and visualization examples are available at the **[MicroFun tutorial website](https://bioscinema.github.io/MicroFun_website_tutorials/)**.

## License

MIT License. See [LICENSE](LICENSE).
