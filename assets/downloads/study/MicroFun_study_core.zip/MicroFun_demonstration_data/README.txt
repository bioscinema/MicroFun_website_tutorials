MicroFun public demonstration data

Source study
Riquelme et al. Tumor Microbiome Diversity and Composition Influence Pancreatic Cancer Outcomes.
Cell 178, 795-806.e12 (2019). DOI 10.1016/j.cell.2019.07.008.
https://pubmed.ncbi.nlm.nih.gov/31398337/
The original sequencing data are publicly available. Please cite the original paper when using these processed demonstration inputs. For additional study information contact Dr. Liangliang Zhang at lxz716@case.edu.

Contents
68 samples, 2777 ASVs. STS 32, LTS 36.
MDA discovery cohort 43 samples, STS 22 and LTS 21.
JHU validation cohort 25 samples, STS 10 and LTS 15.
Sample identifiers are replaced consistently by S001 to S068. Original aliases and sequencing run identifiers are removed. No lookup to original identifiers is included.
phyloseq_asv.RData contains ps, metadata, otu, taxonomy and phylo_tree.
metadata.tsv keeps only sample_name, group, Cohort and CohortRole.
standard contains KO, EC, MetaCyc and the supplied KEGG_2026-11-04 profiles.
stratified files retain all original contribution columns, with sample names replaced. Numeric values are unchanged.
KO 8881 features, EC 2898, MetaCyc 542, KEGG 234.
The date in the KEGG filenames identifies the supplied table export; the underlying KO-to-pathway membership file is not included.

Downloads
Extract the core archive and any required contribution archives into the same parent directory. Each archive contains a MicroFun_demonstration_data folder.
The default taxon-centered analysis needs the core archive and both KO contribution parts, using the bundled mapping to aggregate KOs. The dated KEGG contribution archive is an alternative preaggregated snapshot.
Function-centered KO analysis needs the core archive and both KO contribution archives.
The KO file is split only for transfer. Run source("assemble-data.R") from MicroFun_demonstration_data to reconstruct stratified/KO_contrib.tsv.gz and verify MD5 checksums. Both KO parts must be downloaded. Do not pass .part files directly to MicroFun.
The dated 234-pathway KEGG snapshot differs from the bundled mapping used in the displayed Standard figures. The default examples aggregate the KO table using the package-bundled mapping for consistency.
Standard profiles, the phyloseq object and contribution tables share the same new sample identifiers. Choose the cohort explicitly before analysis; the tutorials default to MDA, and JHU remains available as a separate validation cohort.
