# Assembly applies only to this filtered release; original unfiltered parts are incompatible.
# Run from the directory containing this script.
manifest <- read.csv("manifest.csv", stringsAsFactors = FALSE)
for (i in seq_len(nrow(manifest))) {
  dest <- manifest$path[i]
  if (!file.exists(dest)) {
    parts <- sort(list.files("parts", pattern = paste0("^", basename(dest), "[.]part[0-9]+$"), full.names = TRUE))
    if (!length(parts)) next
    expected_parts <- if (basename(dest) == "KO_contrib.tsv.gz") 2L else 0L
    if (length(parts) != expected_parts) {
      message("Download and extract both KO contribution archives before assembly.")
      next
    }
    dir.create(dirname(dest), recursive = TRUE, showWarnings = FALSE)
    target <- file(dest, "wb")
    for (part in parts) {
      source <- file(part, "rb")
      repeat {
        block <- readBin(source, "raw", n = 8L * 1024L * 1024L)
        if (!length(block)) break
        writeBin(block, target)
      }
      close(source)
    }
    close(target)
  }
  if (file.exists(dest)) {
    actual <- unname(tools::md5sum(dest))
    if (!identical(actual, manifest$md5[i])) stop("Checksum mismatch for ", dest)
    message("Verified ", dest)
  }
}
