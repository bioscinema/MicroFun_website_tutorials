MicroFun filtered demonstration data
Source study: Riquelme et al., Cell (2019), DOI 10.1016/j.cell.2019.07.008.
68 deidentified samples; 2487 ASVs after removing 290 ASVs with Genus labelled Incertae sedis.
The downloaded phyloseq, OTU, taxonomy, ASV tree and contribution tables are filtered consistently.
All four Standard tables were regenerated from the filtered contributions after numerical verification; see filter_summary.csv.
This changes the analyzed dataset and can change PCA, abundance summaries and fitted results.
Genus Incertae sedis denotes uncertain taxonomic placement, not a single resolved genus. Removal prevents pooling unresolved lineages into an artificial genus feature; it is not a contamination finding.

All ZIPs in this release extract into MicroFun_demonstration_data_filtered.
The KO file is split solely for GitHub transfer; use only MicroFun_filtered_KO_part01.zip and MicroFun_filtered_KO_part02.zip.
Run assemble-data.R from this folder to reconstruct the FILTERED KO file and verify checksums.
Never combine this release with the previous unfiltered parts or data directory.
The dated KEGG snapshot is an alternative to aggregation with the installed package's local mapping.
Original sample IDs and private ID lookups are not included. For additional study information contact Dr. Liangliang Zhang, lxz716@case.edu.
